package absyn;

abstract public class Exp extends Absyn {
    public Dec dType;
}
